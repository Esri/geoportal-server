=====================================================
ESRI Geoportal Server
Copyright �2010 Esri. 

=====================================================

This is a Java Web Application providing an ontology service.

Required tools for project compilation and testing:

1. Java SDK 6 (tested against):
   - version 1.6.22 or later
   
2. Servlet Container 2.5 (tested against):
   - Apache Tomcat 6.0.26
   - Glassfish 3.0.1
   - Oracle WebLogic 9i 
   
3. IDE (developed on):
   - Eclipse IDE
   - NetBeans IDE   

=====================================================
   
Quick start:
   
1. Create project within your favorite IDE

2. Compile and deploy.