The GcService.war will be distributed as a separate download, please check the Geoportal Server download page at 
https://github.com/Esri/geoportal-server/wiki/Geoportal-Server-Downloads for latest updates. 

If you would like to know detailed information about Geoportal-Facets, please visit:
https://github.com/Esri/geoportal-server/wiki/Geoportal-Facets