This package include the CSW Search Client and WMC Publish Client for ArcGIS 10.3 Desktop, currently the publish client is not available for ArcGIS 10.3 due to some software constraints.
