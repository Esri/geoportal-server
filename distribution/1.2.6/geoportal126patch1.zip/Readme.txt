Geoportal Server 1.2.6 Patch 1
========================================
- This patch turn off the ability for a user with the publisher role to publish and auto-approve metadata records through the Geoportal Server REST API.
- If you downloaded geoportal-1.2.6.zip before 5/20/2015 6:00 pm pst, you can either redownload or apply this patch. The current geoportal-1.2.6.zip on github already includes the updates in this patch.

========================================
Installation Instructions:
   - Stop Web Application Server (e.g. Tomcat)
   - Make a back up of geoportal\WEB-INF\lib\gpt-1.2.6.jar
   - Copy gpt-1.2.6.jar in this patch to geoportal\WEB-INF\lib
   - Restart the Web Application Server (e.g. Tomcat)
