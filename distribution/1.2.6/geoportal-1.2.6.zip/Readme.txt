Geoportal Server 1.2.6
==========================================================
Please refer to https://github.com/Esri/geoportal-server/wiki about:
* What's new in geoportal server 1.2.6
* Release notes for Geoportal Server 1.2.6
* Instruction on how to setup and configure Geoportal Server