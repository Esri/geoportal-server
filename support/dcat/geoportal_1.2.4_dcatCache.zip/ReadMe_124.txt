 See the NOTICE file distributed with
 this work for additional information regarding copyright ownership.
 Esri Inc. licenses this file to You under the Apache License, Version 2.0
 (the "License"); you may not use this file except in compliance with
 the License.  You may obtain a copy of the License at

     http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.

--- 8< ---

In order to add support for a cached DCAT JSOn file to your Geoportal Server 1.2.4 instance, take the following steps; NOTE, the classes described in step 1 are for Java 7 deployments. If you use Java 6, these classes will not work for you - contact portal@esri.com:

1)  Create a folder structure for the new classes at \\geoportal\WEB-INF\classes\com\esri\gpt\catalog\search , \\geoportal\WEB-INF\classes\com\esri\gpt\control\georss , and \\geoportal\WEB-INF\classes\com\esri\gpt\control\georss\dcatcache . Copy the classes from the patch to the corresponding folder locations.

2)  Add the �dcat� parts to the web.xml sample also included � e.g., this section:

   <servlet>
      <servlet-name>DcatCacheServlet</servlet-name>
      <servlet-class>com.esri.gpt.control.georss.DcatCacheServlet</servlet-class>
    </servlet>
    <servlet-mapping>
      <servlet-name>DcatCacheServlet</servlet-name>
      <url-pattern>/dcat.json</url-pattern>
    </servlet-mapping>

3)  In the gpt.xml file, there are two places where the dcat parameters will be added � look at the sample gpt.xml included in this patch for guidance on where. First, the dcat.cache.path setting; this setting should point to the location of your geoportal web application in Tomcat. This does not have to be web-accessible; just needs to be your geoportal web app root directory:

<!-- DCAT cache directory -->
<parameter key="dcat.cache.path" value="C:\Tomcat7025\webapps\geoportal"/>

4)  Second, set the thread scheduler for how often the cached file is regenerated; default is every 24 hours:

        <!-- DCAT cache generation -->
        <thread class="com.esri.gpt.control.georss.dcatcache.DcatCacheTask" period='1[DAY]' delay="15[SECOND]"/>
    </scheduler>

5)  Then, save the gpt.xml and web.xml files, and restart Tomcat. The DCAT JSON file will begin to be written about 15 seconds after you first start Tomcat.

6)  After a few moments, you should be able to download your DCAT JSON file at this location (substituting for your server name and geoportal web app name: 

http://your_server/geoportal/dcat.json
